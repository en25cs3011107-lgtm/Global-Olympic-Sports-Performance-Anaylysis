# 5–7 Minute Project Demonstration Script

**0:00–0:40 — Introduction**
“Hello, my name is [Your Name]. My project is Global Olympic Sports Performance Analysis. The goal is to explore Olympic participation, medal distribution, country performance, sport categories and regional patterns using data analytics and Tableau.”

**0:40–1:20 — Problem statement**
“Olympic data can be spread across athlete, medal, event and country tables. This project organizes related datasets and turns them into understandable visual summaries so a viewer can compare performance across years, sports and regions.”

**1:20–2:00 — Data preparation**
“First, I inspect column names, data types, missing values and duplicates. I use common fields such as year and country code carefully. Athlete-level records and country-year aggregates have different levels of detail, so I avoid joins that multiply medal totals.”

**2:00–3:30 — Dashboard 1**
“Dashboard 1 focuses on global performance. KPI cards summarize athlete records, sports and nations. The map compares medal totals geographically, the line chart shows trends over time, and bar charts compare countries and sports. I can use the year, country and sport filters to narrow the analysis.”

**3:30–4:45 — Dashboard 2**
“Dashboard 2 focuses on regional efficiency and host performance. It compares regions, medal distribution and host-country totals. The investment-versus-performance chart is exploratory and should not be interpreted as proof that investment alone causes medals.”

**4:45–5:30 — Story and insights**
“The story brings the findings together: participation patterns, leading countries, changes across editions, and differences among sports and regions. The results depend on the coverage and quality of the source data.”

**5:30–6:20 — Validation and limitations**
“I checked data types, missing values, totals and filter behavior. A limitation is that historical Olympic datasets may use different country codes and event definitions. The demonstration CSVs in this starter package are synthetic, so I will replace them with verified source data before presenting factual results.”

**6:20–6:50 — Conclusion**
“This project demonstrates how Tableau can transform structured sports data into interactive dashboards and a narrative story. Thank you.”

Replace bracketed text and adjust the script to match the actual workbook you build. Do not claim that a dashboard or validation step is complete until you have performed it.
