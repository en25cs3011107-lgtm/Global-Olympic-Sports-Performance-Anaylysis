# Global Olympic Sports Performance Analysis

## Important note
This is a complete **starter project package** containing a runnable Flask dashboard, CSV datasets, Tableau build plan, report and presentation script. The included CSVs are **synthetic demonstration data** created so the project runs immediately. They are not official Olympic statistics. Before final submission or public claims, replace them with verified datasets and refresh all charts.

## 1. Run the web dashboard
1. Install Python 3.10+.
2. Extract this ZIP to a folder.
3. Open Command Prompt/Terminal in the project folder.
4. Run:
   ```bash
   python -m venv .venv
   ```
5. Activate the environment:
   - Windows: `.venv\\Scripts\\activate`
   - macOS/Linux: `source .venv/bin/activate`
6. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
7. Start the app:
   ```bash
   python app.py
   ```
8. Open `http://127.0.0.1:5000` in your browser.

Internet is needed to load Chart.js from its CDN.

## 2. Included files
- `data/athletes.csv` — athlete-level demo records.
- `data/medal_results.csv` — medal totals by country and year.
- `data/games_summary.csv` — Olympic edition summary.
- `data/alltime_country_rankings.csv` — country medal ranking and sample investment values.
- `app.py`, `templates/index.html` — Flask dashboard.
- `Project_Report.docx` — editable project report.
- `Tableau_Build_Guide.md` — steps to create the Tableau sheets, dashboards and story.
- `Presentation_Script.md` — 5–7 minute demo script.

## 3. Tableau requirements
Install Tableau Public from the official Tableau Public website. Connect the four CSV files. Use `year` and `country_code` as common fields where available; use relationships or joins carefully to avoid multiplying medal totals. Build the sheets described in `Tableau_Build_Guide.md`, then publish the workbook to Tableau Public. Published workbooks are public, so do not publish private information.

## 4. Suggested final deliverables
- Tableau Public workbook link
- GitHub repository link (optional)
- 2 dashboards + story
- 5–7 minute screen recording
- Project report
- Screenshots of data source, worksheets, dashboards, story and published workbook

## 5. Data caution
Numbers shown in the included sample data are generated for demonstration only. Do not present them as verified Olympic facts.
