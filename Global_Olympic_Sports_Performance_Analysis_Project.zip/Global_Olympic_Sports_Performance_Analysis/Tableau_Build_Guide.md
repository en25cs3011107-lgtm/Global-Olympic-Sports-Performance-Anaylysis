# Tableau Build Guide

## Data source setup
Connect these CSVs separately in Tableau:
1. `athletes.csv`
2. `medal_results.csv`
3. `games_summary.csv`
4. `alltime_country_rankings.csv`

Use relationships rather than blindly joining all tables. `athletes.csv` is athlete/event-level; `medal_results.csv` is country-year aggregate; combining them at row level can duplicate totals. Verify totals after each relationship.

## Calculated fields (adjust to actual column names)
**Total Medals**
```
ZN(SUM([gold])) + ZN(SUM([silver])) + ZN(SUM([bronze]))
```
**Medal Efficiency %** (only if athlete participation denominator is meaningful and consistently defined)
```
IF SUM([athletes_sent]) = 0 THEN 0
ELSE 100 * SUM([total_medals]) / SUM([athletes_sent])
END
```
**Year**
Use the numeric `year` field as a discrete dimension for filters or continuous for trend axes.

## Suggested worksheets (10)
1. KPI — Global Athlete Participation: COUNTD([athlete_id])
2. KPI — Total Sports Categories: COUNTD([sport])
3. KPI — Total Nations Represented: COUNTD([country_code])
4. Total Medal Achievements Across Nations — map using country and SUM([total_medals])
5. Trend of Total Medals Awarded Over the Years — line chart, `year` vs SUM([total_medals])
6. Avg Medals per Athlete by Sport Category — horizontal bar, sport vs medals / athlete count
7. Global Performance Metrics by Country — vertical bar; create a parameter to switch total/gold/silver/bronze if desired
8. Average Medal Efficiency Percentage by Region — pie chart
9. Global Sports Investment vs Medal Performance — bubble/scatter plot using investment and medal total
10. Comparing Medal Totals Across Olympic Hosts — horizontal bar by host country
11. Regional Medal Efficiency and Distribution by Sport — donut chart (dual-axis pie technique) or a simple pie if easier

Note: the brief lists 10 visualization groups but some are KPI tiles, so using 10–11 worksheets is reasonable.

## Dashboard 1: Global Sports Performance
- Title banner
- KPI tiles: athlete participation, sports categories, nations represented
- World map: medal totals by country
- Line chart: medal trend by year
- Horizontal bar: average medals per athlete by sport
- Vertical bar: medal metrics by country
- Filters: year, sport category, country
- Apply each filter to relevant worksheets using “Apply to Worksheets > All Using Related Data Sources” only after verifying relationships.

## Dashboard 2: Olympic Performance & Regional Efficiency
- KPI tiles: regional efficiency, countries participating, athlete participation count
- Pie: medal efficiency by region
- Bubble chart: sports investment vs medal performance
- Horizontal bar: host nation medal comparison
- Donut/pie: regional medal distribution by sport
- Filters: region and host country

## Story
Create 4–5 story points:
1. Global participation overview
2. Countries and medal distribution
3. Medal trends across editions
4. Sport and regional efficiency
5. Summary and limitations

## Styling
Use dark navy, teal/green and gold accents. Keep text readable, align charts, use consistent number formats and add concise chart captions.

## Validation
- Compare medal totals before and after relationships.
- Check missing values and data types.
- Ensure filters update the intended worksheets.
- Confirm labels and tooltips are readable.
- Save a local `.twb`/`.twbx` and publish to Tableau Public.
