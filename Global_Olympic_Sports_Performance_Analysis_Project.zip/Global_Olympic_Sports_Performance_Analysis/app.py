from flask import Flask, render_template, jsonify
import pandas as pd
from pathlib import Path

app = Flask(__name__)
DATA = Path(__file__).parent / "data"

def load_csv(name):
    path = DATA / name
    return pd.read_csv(path).fillna(0)

@app.route("/")
def index():
    athletes = load_csv("athletes.csv")
    medals = load_csv("medal_results.csv")
    games = load_csv("games_summary.csv")
    rankings = load_csv("alltime_country_rankings.csv")
    medal_winners = athletes[athletes["medal"].isin(["Gold", "Silver", "Bronze"])]
    total_medals = int(medals["total_medals"].sum())
    return render_template(
        "index.html",
        athlete_count=int(athletes["athlete_id"].nunique()),
        country_count=int(rankings["country"].nunique()),
        sports_count=int(athletes["sport"].nunique()),
        total_medals=total_medals,
        years=sorted(athletes["year"].unique().tolist()),
        sports=sorted(athletes["sport"].unique().tolist()),
        regions=sorted(rankings["region"].unique().tolist()),
        data_note="Demonstration data generated for this starter project; replace with verified Olympic data before final submission."
    )

@app.route("/api/summary")
def summary():
    athletes = load_csv("athletes.csv")
    medals = load_csv("medal_results.csv")
    rankings = load_csv("alltime_country_rankings.csv")
    year = athletes.groupby("year")["athlete_id"].nunique().sort_index()
    sport = athletes.groupby("sport")["athlete_id"].nunique().sort_values(ascending=False).head(10)
    country = rankings.sort_values("total_medals", ascending=False).head(10)
    region = rankings.groupby("region")["total_medals"].sum().sort_values(ascending=False)
    medal_counts = athletes[athletes["medal"].isin(["Gold","Silver","Bronze"])].groupby("medal")["athlete_id"].nunique()
    return jsonify({
        "year_labels": [int(x) for x in year.index],
        "year_values": [int(x) for x in year.values],
        "sport_labels": sport.index.tolist(),
        "sport_values": [int(x) for x in sport.values],
        "country_labels": country["country"].tolist(),
        "country_values": [int(x) for x in country["total_medals"].tolist()],
        "region_labels": region.index.tolist(),
        "region_values": [int(x) for x in region.values],
        "medal_labels": medal_counts.index.tolist(),
        "medal_values": [int(x) for x in medal_counts.values]
    })

if __name__ == "__main__":
    app.run(debug=True)
